package com.arc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Morn15InquiryApplicationTests {

	@Test
	void contextLoads() {
	}

}
