package com.arc.cont;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.arc.entity.Inquiry;
import com.arc.repo.InquiryRepo;

@RestController
public class InquiryController {

	@Autowired
	private InquiryRepo inquiryRepo;
	
	@PostMapping("{fullname}/{email}/{course}/{city}")
	public Inquiry savedata(@PathVariable("fullname")String fullname,
			@PathVariable("email") String email,@PathVariable("course") String course,@PathVariable("city") String city)
	{
		Inquiry pd = new Inquiry();
	
		pd.setFullname(fullname);
		pd.setEmail(email);
		pd.setCourse(course);
		pd.setCity(city);
		
		return inquiryRepo.save(pd);

	}
	
	@GetMapping("/edit/{id}")
	public Inquiry getempById(@PathVariable("id") int id) {
		Inquiry list =inquiryRepo.getInqById(id);
		System.out.println(list);
		System.out.println(id);
		 return list;
	    }
			

	
	@GetMapping("delete/{id}")
	public String deleteEmpoyee(@PathVariable int id)
	{
		System.out.println(id);
		 inquiryRepo.deleteById(id);
		return ("Deleted Successfully");
	}

}
