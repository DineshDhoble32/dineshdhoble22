package com.arc.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.ToString;

@ToString
@Data
@Entity
public class Inquiry {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	private String fullname;
	private String email;
	private long phoneNumber=(long)(Math.random()*Math.pow(10, 10));
	private String course;
	private LocalDate date;
	private String city;
	
}
