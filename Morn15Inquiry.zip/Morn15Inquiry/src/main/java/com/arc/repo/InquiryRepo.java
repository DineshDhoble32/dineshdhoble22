package com.arc.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.arc.entity.Inquiry;

public interface InquiryRepo extends JpaRepository<Inquiry, Long> {

	Inquiry getInqById(int id);

	void deleteById(int id);

}
